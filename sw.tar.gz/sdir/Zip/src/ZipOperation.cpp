//
// ZipOperation.cpp
//
// Library: Zip
// Package: Manipulation
// Module:  ZipOperation
//
// Copyright (c) 2007, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/Zip/ZipOperation.h"


namespace Poco {
namespace Zip {


ZipOperation::ZipOperation()
{
}


ZipOperation::~ZipOperation()
{
}


} } // namespace Poco::Zip
